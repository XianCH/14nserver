There are still two wallpapers I use but their size is a little big. 
See the links below :

[https://wallhaven.cc/w/3z2med](https://wallhaven.cc/w/3z2med)

[https://wallhaven.cc/w/6oxgp6](https://wallhaven.cc/w/6oxgp6)

A collection of wallpapers that may fit the Nordic Theme: [https://github.com/linuxdotexe/nordic-wallpapers](https://github.com/linuxdotexe/nordic-wallpapers)
