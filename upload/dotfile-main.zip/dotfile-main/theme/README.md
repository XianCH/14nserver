See 
[https://github.com/EliverLara/Nordic](https://github.com/EliverLara/Nordic)
and 
[https://github.com/zayronxio/Zafiro-Nord-Dark](https://github.com/zayronxio/Zafiro-Nord-Dark)
and[https://github.com/catppuccin](https://github.com/catppuccin)
