#!/bin/bash
rofi -show p -modi p:~/.config/rofi/off.sh -theme ~/.config/rofi/nord.rasi
