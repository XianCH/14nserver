local status_ok,tz=pcall(require,"true-zen")
if not status_ok then
  return
end


tz.setup()
