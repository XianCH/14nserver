require("user.core.cmp")
require("user.core.code_runner")
require("user.core.nvim-tree")
require("user.core.telescope")
require("user.core.term")
require("user.core.treesitter") 
require("user.core.comment")
require("user.core.autopairs")


require("user.core.project")
