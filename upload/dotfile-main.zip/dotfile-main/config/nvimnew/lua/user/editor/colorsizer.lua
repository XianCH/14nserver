
return function()
  local color1 = require("colorizer")
  color1.setup(


  )
end
