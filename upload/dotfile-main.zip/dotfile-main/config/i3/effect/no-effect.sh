feh ~/Pictures/nord1.png --bg-fill

pkill picom 

picom --config ~/.config/picom/picom.conf1 & disown
