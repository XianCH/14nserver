feh ~/Pictures/wallhaven-6oxgp6.jpg --bg-fill

pkill picom 

picom --config ~/.config/picom/ftlab.conf & disown
