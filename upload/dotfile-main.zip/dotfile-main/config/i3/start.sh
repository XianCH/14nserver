sh /home/charles/.config/i3/volume.sh &

sh /home/charles/.config/i3/brightness.sh &
