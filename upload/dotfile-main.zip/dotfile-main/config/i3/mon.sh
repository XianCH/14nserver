xrandr --output HDMI-A-0 --same-as eDP &
