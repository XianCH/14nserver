gummy start
